package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class FirebaseData extends AppCompatActivity {
    private String component;
    private int voltage;
    private int current;
    private int totalpower;

    private String energyid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase_data);
        FirebaseDatabase energydata = FirebaseDatabase.getInstance();
        DatabaseReference ref = energydata.getReference();

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                writedataonthescreen(dataSnapshot);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void writedataonthescreen(DataSnapshot datasnaapshot)
    {
       for(DataSnapshot ds : datasnaapshot.getChildren())
       {
           querysnapshot newinfo = new querysnapshot();
           newinfo = ds.getValue(querysnapshot.class);
           Log.d("LOGTAG", newinfo.getcomponent());

       }

    }
}


