package com.example.myapplication;

public class querysnapshot {
    String mcomponent;
    int mvolatge;
    int mcurrent;
    int mpower;
    public querysnapshot() {
    }
    public void setcomponent(String component)
    {
        mcomponent = component;
    }
    public void setMpower( int Power)
    {
       mpower = Power;
    }
    public void setMvolatge(int voltage)
    {
        mvolatge = voltage;
    }
    public void setCurrent(int Current)
    {
      mcurrent = Current;
    }
    public String getcomponent()
    {
        return mcomponent;
    }
    public int getCurrent()
    {
        return mcurrent;
    }
    public int getVoltage()
    {
        return mvolatge;
    }
    public int getpower()
    {
        return mpower;
    }
}
