package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class settings extends Activity {
    BottomNavigationView mbottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        mbottomNavigationView = (BottomNavigationView) findViewById(R.id.navigationView) ;
        Menu menu = mbottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);
        mbottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.navigation_settings: {
                        break;
                    }

                    case R.id.navigation_energy:
                    {
                        Intent newIntent = new Intent(settings.this, energy.class);
                        startActivity(newIntent);
                        break;
                    }
                    case R.id.navigation_home:
                    {
                        Intent newIntent = new Intent(settings.this, MainActivity.class);
                        startActivity(newIntent);
                        break;
                    }
                }
                return false;
            }
        });


    }
}
